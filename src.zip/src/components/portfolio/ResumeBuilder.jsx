'use client';

import React, { useState } from 'react';
import { useGetResumeProjectQuery } from '@/services/api/portfolioApi';
import Loader from '@/components/common/Loader';
import BasicInfoSection from '@/components/portfolio/sections/BasicInfoSection';
import SocialLinksSection from '@/components/portfolio/sections/SocialLinksSection';
import EducationSection from '@/components/portfolio/sections/EducationSection';
import ExperienceSection from '@/components/portfolio/sections/ExperienceSection';
import SkillsSection from '@/components/portfolio/sections/SkillsSection';
import ProjectsSection from '@/components/portfolio/sections/ProjectsSection';
import CertificatesSection from '@/components/portfolio/sections/CertificateSection';
import { FiEye, FiDownload, FiArrowLeft, FiChevronDown, FiSettings } from 'react-icons/fi';
import { useRouter } from 'next/navigation';
import { ROUTES } from '@/routes/routes.constants';
import styles from '@/styles/portfolio/resume/ResumeBuilder.module.css';

const SECTIONS = [
    { id: 'basic-info', title: 'Basic Info', component: BasicInfoSection },
    { id: 'social-links', title: 'Social Links', component: SocialLinksSection },
    { id: 'experience', title: 'Experience', component: ExperienceSection },
    { id: 'education', title: 'Education', component: EducationSection },
    { id: 'skills', title: 'Skills', component: SkillsSection },
    { id: 'projects', title: 'Projects', component: ProjectsSection },
    { id: 'certificates', title: 'Certificates', component: CertificatesSection },
];

export default function ResumeBuilder({ resumeId, onBack, onPreview, onGeneratePDF }) {
    const router = useRouter();
    const [activeSection, setActiveSection] = useState('basic-info');
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

    const { data, isLoading } = useGetResumeProjectQuery(resumeId, { skip: !resumeId });
    const resume = data?.data;

    const snapshotId = resume?.profile_snapshot_id || resume?.profile_snapshot;
    const ActiveComponent = SECTIONS.find(s => s.id === activeSection)?.component;

    if (isLoading) return <Loader text="Loading resume builder..." />;

    return (
        <div className={styles.builder}>
            {/* Minimal Top Bar */}
            <div className={styles.topBar}>
                <button onClick={onBack} className={styles.backBtn} title="Back to Resumes">
                    <FiArrowLeft size={16} />
                </button>
                <span className={styles.resumeTitle}>{resume?.title || 'Resume'}</span>
                <div className={styles.topActions}>
                    <button
                        className={styles.iconBtn}
                        onClick={() => router.push(ROUTES.DASHBOARD.PORTFOLIO.RESUME.EDIT(resumeId))}
                        title="Resume Settings"
                    >
                        <FiSettings size={16} />
                    </button>
                    {resume?.is_public && (
                        <button className={styles.iconBtn} onClick={() => onPreview(resume.slug)} title="Preview">
                            <FiEye size={16} />
                        </button>
                    )}
                    <button className={styles.iconBtn} onClick={() => onGeneratePDF(resumeId)} title="Export PDF">
                        <FiDownload size={16} />
                    </button>
                </div>
            </div>

            <div className={styles.builderBody}>
                {/* Left Panel */}
                <div className={styles.leftPanel}>
                    {/* Mobile Dropdown */}
                    <div className={styles.mobileNav}>
                        <button
                            className={styles.mobileNavBtn}
                            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                        >
                            {SECTIONS.find(s => s.id === activeSection)?.title || 'Select Section'}
                            <FiChevronDown size={14} />
                        </button>
                        {mobileMenuOpen && (
                            <div className={styles.mobileDropdown}>
                                {SECTIONS.map((section) => (
                                    <button
                                        key={section.id}
                                        className={`${styles.mobileDropdownItem} ${activeSection === section.id ? styles.active : ''}`}
                                        onClick={() => {
                                            setActiveSection(section.id);
                                            setMobileMenuOpen(false);
                                        }}
                                    >
                                        {section.title}
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>

                    {/* Desktop Tabs */}
                    <div className={styles.desktopNav}>
                        {SECTIONS.map((section) => (
                            <button
                                key={section.id}
                                className={`${styles.navItem} ${activeSection === section.id ? styles.active : ''}`}
                                onClick={() => setActiveSection(section.id)}
                            >
                                {section.title}
                            </button>
                        ))}
                    </div>

                    {/* Section Content */}
                    <div className={styles.sectionContent}>
                        {ActiveComponent && snapshotId && (
                            <ActiveComponent snapshotId={snapshotId} />
                        )}
                    </div>
                </div>

                {/* Right Panel - Live Preview */}
                <div className={styles.rightPanel}>
                    <div className={styles.previewLabel}>Live Preview</div>
                    <div className={styles.previewFrame}>
                        {resume?.slug ? (
                            <iframe
                                src={`/resume/${resume.slug}?embed=true`}
                                className={styles.previewIframe}
                                title="Resume Preview"
                            />
                        ) : (
                            <div className={styles.previewPlaceholder}>
                                <p>Make your resume public to see the live preview</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}